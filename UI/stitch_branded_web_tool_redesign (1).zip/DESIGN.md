---
name: Heavy Industrial Engineering
colors:
  surface: '#f6faff'
  surface-dim: '#cadced'
  surface-bright: '#f6faff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#ebf5ff'
  surface-container: '#e0f0ff'
  surface-container-high: '#d8eafb'
  surface-container-highest: '#d3e5f5'
  on-surface: '#0c1d29'
  on-surface-variant: '#3e484d'
  inverse-surface: '#22323f'
  inverse-on-surface: '#e5f2ff'
  outline: '#6e797e'
  outline-variant: '#bec8ce'
  surface-tint: '#006781'
  primary: '#00647e'
  on-primary: '#ffffff'
  primary-container: '#007f9f'
  on-primary-container: '#fafdff'
  inverse-primary: '#75d2f6'
  secondary: '#50606f'
  on-secondary: '#ffffff'
  secondary-container: '#d0e2f4'
  on-secondary-container: '#546574'
  tertiary: '#785600'
  on-tertiary: '#ffffff'
  tertiary-container: '#986d00'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#baeaff'
  primary-fixed-dim: '#75d2f6'
  on-primary-fixed: '#001f29'
  on-primary-fixed-variant: '#004d62'
  secondary-fixed: '#d3e5f6'
  secondary-fixed-dim: '#b7c9da'
  on-secondary-fixed: '#0c1d2a'
  on-secondary-fixed-variant: '#384957'
  tertiary-fixed: '#ffdea6'
  tertiary-fixed-dim: '#ffbb10'
  on-tertiary-fixed: '#271900'
  on-tertiary-fixed-variant: '#5d4200'
  background: '#f6faff'
  on-background: '#0c1d29'
  surface-variant: '#d3e5f5'
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
  label-md:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  label-technical:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-technical-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system translates the heavy-lifting precision, structural integrity, and industrial reliability of heavy machinery logistics into a high-density, mission-critical web application. Inspired by the geometric weight and deliberate mass of industrial transport, the aesthetic merges technical precision engineering with authoritative European transport typography.

The style operates as an **Industrial High-Utility Interface**:
- **Engineering Rigor:** Clean geometric architecture, dense data displays, explicit line work, and tactile status indicators that convey technical certitude.
- **Structural Strength:** Monolithic headers, authoritative badges, and high-contrast structural accents derived directly from heavy-duty equipment livery.
- **Utilitarian Balance:** High-readability data tables, mechanical schematics, and functional color coding that prioritize zero error tolerance and instantaneous cognitive parsing.

## Colors

The color palette directly implements the heavy logistics visual identity:

- **Primary (`#0083A4` / Sea Blue / RAL 5021):** The core brand anchor. Used for primary interactive triggers, active navigation items, key schematics, and major status milestones.
- **Secondary (`#132431` / Industrial Navy-Slate):** Grounding color for dense chrome, table headers, top navigation, and structural framing. Deep variations (`#0C1A24`) form heavy contrast boundaries, while lighter slate steps (`#1A3142`) supply elevation panels.
- **Tertiary (`#FAB600` / Signal Yellow / RAL 1003):** Operational warning and high-alert accent. Reserved for critical callouts, crane load warnings, high-priority status badges, and attention-critical action triggers.
- **Neutral & Canvas (`#F4F7F9` to `#5A6B79`):** Crisp technical ice-white background (`#F4F7F9`) prevents eye fatigue under warehouse or field lighting, with neutral slate (`#5A6B79`) utilized for secondary data parameters, structural grid rules, and engineering annotations.

### Functional Roles
- **Success:** `#107C41` (Load Safe / Approved)
- **Warning:** `#FAB600` (Capacity Limit / Caution)
- **Critical / Hazard:** `#D83B01` (Overload / Emergency Halt)
- **Data Blueprint / Grid Line:** `rgba(0, 131, 164, 0.15)`

## Typography

The typographic hierarchy establishes clear technical precision:

- **Headlines (Space Grotesk):** Engineered geometry with high horizontal stability and solid stroke weights that mirror the muscular silhouette of heavy transport logos. Used for major toolbars, view titles, and module headings.
- **Body (Hanken Grotesk):** Crisp, neo-grotesque legibility designed to maintain optical balance in dense technical workflows, equipment specs, and multi-field forms.
- **Technical & Data (JetBrains Mono):** Essential for load weights, axle load calculations, GPS coordinates, vehicle registrations, and real-time sensor metrics to guarantee alignment in tabular displays.

## Layout & Spacing

The layout follows a high-density, multi-panel engineering grid designed for desktop workstations and ruggedized field tablets.

- **System Grid:** A 12-column fluid grid system with compact 16px (`1rem`) gutters on field viewports and 24px (`1.5rem`) on wide engineering displays.
- **Density Control:** Data density is prioritized over decorative spacing. Metric clusters and parameter readouts conform to strict 4px/8px baselines.
- **Pane Architecture:** A persistent left utility bar (56px collapsed / 240px expanded) for transport modules, a fixed top bar for operation telemetry and alert banners, and a multi-column split view for schematic blueprints and real-time load telemetry.
- **Responsive Adaptations:**
  - **Desktop (>=1200px):** Simultaneous schematic viewing alongside live table metrics and lift rigging inspectors.
  - **Tablet (768px - 1199px):** Collapsible schematic canvas with bottom-sheet metric drawers.
  - **Mobile (<768px):** Single-column stacked telemetry cards, prioritized action sheets, and full-width technical data tables with horizontal scroll anchors.

## Elevation & Depth

Visual hierarchy uses **tonal layering and low-contrast mechanical outlines** rather than soft ambient blur or floating drop shadows, preserving an industrial, CAD-like instrument feel:

- **Level 0 (App Canvas):** Crisp technical ice-white (`#F4F7F9`) in standard mode or Slate Base (`#0C1A24`) in industrial dark mode.
- **Level 1 (Data Cards & Worksheets):** Solid white (`#FFFFFF`) with a 1px border of `#D3DDE5` (or `#1A3142` in dark mode). No shadow.
- **Level 2 (Active Tools, Modals & Menus):** Pure background with a precise hairline outline (`1px solid #0083A4`) and an engineered directional drop: `0px 4px 12px rgba(12, 26, 36, 0.12)`.
- **Level 3 (Overlay Inspect & Safety Alerts):** Bounded by a 2px Signal Yellow (`#FAB600`) or Sea Blue (`#0083A4`) perimeter frame with a high-contrast boundary shadow: `0px 8px 24px rgba(12, 26, 36, 0.22)`.

## Shapes

The shape system adopts a **softened structural industrial geometry** (Level 1). Radii are tight and functional, echoing fabricated steel containers, truck cabs, and crane chassis:

- **Containers, Modules & Cards:** 4px (`rounded-sm` / `0.25rem`) corner rounding to maintain architectural solidity without appearing harsh.
- **Input Fields, Tool Buttons & Badges:** 4px radius for crisp edge alignment along tabular vertical grids.
- **Status Pills & Toggles:** 6px to 8px maximum (`rounded-lg`); full circular pill shapes are avoided to preserve the mechanical engineering identity.

## Components

### Buttons
- **Primary:** Solid Sea Blue (`#0083A4`) fill, white bold Space Grotesk text, 4px radius, 0px border. Hover: `#006C87`. Active: `#00576D`.
- **Secondary / Technical:** Slate transparent surface, 1px solid `#132431` border, text `#132431`. Hover: `#132431` fill with white text.
- **Hazard / Critical Action:** Signal Yellow (`#FAB600`) fill with contrasting Dark Slate (`#0C1A24`) text and 1px `#D99E00` stroke.

### Input Fields & Technical Steppers
- **Frame:** 1px solid `#CBD6DF` on white canvas; 40px height for standard inputs, 32px for micro-inspector panels.
- **Focus:** 1.5px Sea Blue (`#0083A4`) outline with subtle `rgba(0, 131, 164, 0.15)` inner glow.
- **Units/Suffix Badges:** Integrated monospaced unit badges (e.g., `[t]`, `[kN]`, `[m]`) locked to the right interior border with Slate neutral fill.

### Data Tables
- **Header:** Deep Slate Navy (`#132431`) background with crisp white uppercase labels (`label-technical-sm`).
- **Rows:** Alternating rows using `#FFFFFF` and `#F8FAFC`. 1px horizontal rule `#E2E8F0`.
- **Cell Typography:** JetBrains Mono for all numeric measurements, load ratings, and equipment tags to ensure tabular decimal alignment.

### Status Badges & Engineering Chips
- **Structural Spec:** Monospaced 11px uppercase with 2px vertical indicator bar on the left edge.
- **Nominal / In Service:** Sea Blue soft tint (`#E5F3F6`) background with Sea Blue text and `#0083A4` border.
- **Warning / Inspection Due:** Signal Yellow tint (`#FEF7E6`) background with `#8A6400` text and `#FAB600` left accent.
- **Overload / Critical Alert:** Red tint (`#FDEBE9`) with `#A80000` text and bold `#D83B01` outline.

### Cards & Schematics Viewers
- Precision blueprint frame with a 1px border.
- Optional 4px colored accent bar at top border representing asset class: Sea Blue for cranes and mobile transport units, Signal Yellow for load indicators and warnings.
- Dark mode blueprint canvas (`#0C1A24`) featuring high-contrast Sea Blue line vectors and Signal Yellow centroid center-of-gravity markers.